enum ItemType: String, CaseIterable, Codable {
    case task = "Task"
    case note = "Note"
}
