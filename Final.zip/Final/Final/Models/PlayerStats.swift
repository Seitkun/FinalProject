struct PlayerStats: Codable {
    var level: Int = 1
    var experience: Int = 0
    var productivity: Int = 0
    var knowledge: Int = 0
}
