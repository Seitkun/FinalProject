import SwiftUI

@main
struct FinalApp: App {
    

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
